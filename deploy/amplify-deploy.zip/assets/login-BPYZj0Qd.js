import{s as t,j as e,R as o,q as r}from"./main-DoqAT9XD.js";t.createRoot(document.getElementById("root")).render(e.jsx(o.StrictMode,{children:e.jsx(r,{})}));
