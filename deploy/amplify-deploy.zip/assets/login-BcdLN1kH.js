import{s as t,j as e,R as o,q as r}from"./main-DN30sRSE.js";t.createRoot(document.getElementById("root")).render(e.jsx(o.StrictMode,{children:e.jsx(r,{})}));
